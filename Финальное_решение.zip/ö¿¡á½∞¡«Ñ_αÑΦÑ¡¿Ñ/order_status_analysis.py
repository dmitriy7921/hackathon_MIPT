import pandas as pd
import matplotlib.pyplot as plt

orders_df = pd.read_csv('DATA\\orders.csv', low_memory=False)
order_reviews_df = pd.read_csv('DATA\\order_reviews.csv', low_memory=False)

orders_df = orders_df[['order_id', 'order_status']].merge(order_reviews_df[['order_id', 'review_score']], on='order_id', how='inner').reset_index(drop=True)

order_status_conversion = orders_df.groupby('order_status').agg({
    'order_id': 'count',
    'review_score': 'mean'
}).reset_index()

order_status_conversion.rename(columns={
    'order_id': 'num_orders',
    'review_score': 'mean_review_score'
}, inplace=True)

print(order_status_conversion)

fig, axes = plt.subplots(1, 2, figsize=(14, 6))

axes[0].bar(x=order_status_conversion['order_status'],
            height=order_status_conversion['mean_review_score'],
            color='skyblue')
axes[0].set_title('Mean Review Score vs Order Status')
axes[0].set_xlabel('Order Status')
axes[0].set_ylabel('Mean Review Score')
axes[0].set_ylim(0, order_status_conversion['mean_review_score'].max() * 1.2)

axes[1].bar(x=order_status_conversion['order_status'],
            height=order_status_conversion['num_orders'],
            color='skyblue')
axes[1].set_title('Number of Orders vs Order Status')
axes[1].set_xlabel('Order Status')
axes[1].set_ylabel('Number of Orders')
axes[1].set_ylim(0, order_status_conversion['num_orders'].max() * 1.2)

plt.tight_layout()
plt.show()