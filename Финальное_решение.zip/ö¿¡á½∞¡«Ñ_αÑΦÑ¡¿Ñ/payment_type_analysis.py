import pandas as pd
import matplotlib.pyplot as plt

order_payments_df = pd.read_csv('DATA\\order_payments.csv', low_memory=False)
orders_df = pd.read_csv('DATA\\orders.csv', low_memory=False)
order_reviews_df = pd.read_csv('DATA\\order_reviews.csv', low_memory=False)

order_payments_df = order_payments_df[['order_id', 'payment_type']].merge(orders_df[['order_id', 'customer_id']], on='order_id', how='inner').reset_index(drop=True)
order_payments_df = order_payments_df.merge(order_reviews_df[['order_id', 'review_score']], on='order_id', how='inner').reset_index(drop=True)

payment_conversion = order_payments_df.groupby('payment_type').agg({
    'order_id': 'count',
    'review_score': 'mean'
}).reset_index()

payment_conversion.rename(columns={
    'order_id': 'num_orders',
    'review_score': 'mean_review_score'
}, inplace=True)

print(payment_conversion)

fig, axes = plt.subplots(1, 2, figsize=(14, 6))

axes[0].bar(x=payment_conversion['payment_type'],
            height=payment_conversion['mean_review_score'],
            color='skyblue')
axes[0].set_title('Mean Review Score vs Payment Type')
axes[0].set_xlabel('Payment Type')
axes[0].set_ylabel('Mean Review Score')
axes[0].set_ylim(0, payment_conversion['mean_review_score'].max() * 1.2)

axes[1].bar(x=payment_conversion['payment_type'],
            height=payment_conversion['num_orders'],
            color='skyblue')
axes[1].set_title('Number of Orders vs Payment Type')
axes[1].set_xlabel('Payment Type')
axes[1].set_ylabel('Number of Orders')
axes[1].set_ylim(0, payment_conversion['num_orders'].max() * 1.2)

plt.tight_layout()
plt.show()